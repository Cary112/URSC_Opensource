# URSC evaluation protocol

The paper evaluates URSC across three benchmarks with two frozen downstream
modules. This document describes the protocol that the repository mirrors.

## Benchmark coverage

| Benchmark | Split | Role | Primary metrics |
| --- | --- | --- | --- |
| **RoboRefIt** | complete testA / testB | Stage I 2D target understanding | REC (box IoU ≥ 0.5), RES (mask mIoU) |
| **RoboRefIt** | frozen **testB-300** | Stage II re-sampling + calibration | Empty, AP, NDCG@5, Top-1, Hit@1 |
| **OCID-VLG** | novel (unseen classes) | cross-dataset transfer | mIoU, empty rate |
| **GraspNet-1Billion** | official test | downstream generation | AP (overall / seen / similar / novel), 23,040 frames |

## Frozen downstream modules

- **Primary:** FGC-GraspNet (frozen) — a 6-DoF grasp generator.
- **Cross-module check:** OVGNet's frozen GraspNet submodule.

Both are frozen. The **testB-300** protocol fixes the downstream-module and
query inputs, so that any measured gain isolates the **interface change**
(re-sampling + spatial-consistency calibration) from downstream capacity. The
testB-300 list is chosen by `scene_stratified_random` with a fixed seed.

## Interface setup

- **Front end:** a language-conditioned 2D segmentation model (HiFi-CS adapted;
  2.11M params, 35,073 expressions, 1.39% of HiFi-CS). Frozen SAM-B provides
  candidate masks.
- **Candidate input:** 20,000 points.
- **Hardware:** RTX 4060 Laptop GPU (8 GB).
- **Statistics:** 20,000 paired bootstrap repetitions, 95% confidence intervals,
  computed sample-aligned (paired design) on the frozen testB-300 list.

## Reported metrics

- **REC / RES:** box IoU ≥ 0.5 and mask mIoU on the localization task.
- **Empty:** fraction of samples with no valid query surviving the nominal branch.
- **AP / NDCG@5 / Top-1 / Hit@1:** offline proxies for candidate quality and
  ranking on the frozen list; latency in ms.
- **mIoU / empty rate:** on the OCID-VLG novel split.
- **GraspNet AP:** official protocol, overall and seen/similar/novel.

> Lines that are *out-of-protocol* (e.g. the nominal-branch AP/NDCG columns) are
> reported as dashes in the paper, because an empty response yields no ranked
> candidate to score.

## Reproducibility

Re-running the full evaluation requires the private project: the frozen model
artifacts, the 300-image manifest, the aligned Stage I masks, and the frozen
downstream weights are intentionally outside this reference repository. The
repository provides the protocol definitions and the paired-bootstrap estimator
(`evaluation/bootstrap_ci.py`) so the statistics can be recomputed from aligned
per-sample metric arrays.
