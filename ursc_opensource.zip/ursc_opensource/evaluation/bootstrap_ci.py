"""Paired bootstrap confidence intervals.

The paper reports paired bootstrap repetitions (20,000) with 95% confidence
intervals. This module implements the paired bootstrap estimator used to
produce the reported CIs on the frozen testB-300 protocol.
"""

from __future__ import annotations

import numpy as np


def paired_bootstrap_ci(
    control: np.ndarray,          # (N,) baseline metric per sample
    treated: np.ndarray,          # (N,) URSC metric per sample
    n_bootstrap: int = 20000,
    ci_level: float = 0.95,
    seed: int = 20260720,
) -> dict:
    """Paired bootstrap CI on the mean improvement (treated - control).

    The two arrays must be aligned sample-by-sample (paired design), which is
    the convention the paper uses for the frozen testB-300 list.
    """
    control = np.asarray(control, dtype=float)
    treated = np.asarray(treated, dtype=float)
    if control.shape != treated.shape:
        raise ValueError("control and treated must be sample-aligned (paired)")
    diff = treated - control                       # (N,)
    if diff.size < 2:
        raise ValueError("need at least two paired samples")
    rng = np.random.default_rng(seed)
    n = diff.size
    idx = rng.integers(0, n, size=(n_bootstrap, n))
    means = diff[idx].mean(axis=1)
    alpha = 1.0 - ci_level
    lo = float(np.percentile(means, 100 * alpha / 2))
    hi = float(np.percentile(means, 100 * (1 - alpha / 2)))
    return {
        "mean_diff": float(diff.mean()),
        "median_diff": float(np.median(diff)),
        "ci_level": ci_level,
        "ci_low": lo,
        "ci_high": hi,
        "n_bootstrap": n_bootstrap,
        "n_pairs": n,
        "significance": not (lo <= 0 <= hi),
    }


def summarize_stratified(controls, treated, seeds):
    """Paired bootstrap over a stratified set of pre-partitioned samples."""
    return {
        str(seed): paired_bootstrap_ci(controls[k], treated[k]) for k, seed in enumerate(seeds)
    }
