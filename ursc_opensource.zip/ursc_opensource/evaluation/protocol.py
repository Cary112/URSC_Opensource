"""Evaluation protocol configuration.

This mirrors the evaluation protocol described in the paper's experiments:
the complete RoboRefIt testA/B splits, a frozen testB-300 candidate list, the
OCID-VLG novel split, and 23,040 official GraspNet-1Billion RealSense frames.
FGC-GraspNet is the primary frozen downstream module and OVGNet's frozen
GraspNet submodule is the cross-module check.

The protocol deliberately isolates the interface change from downstream
capacity: testB-300 fixes the downstream-module and query inputs.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class EvaluationProtocol:
    name: str
    split: str
    frozen: bool = True
    n_bootstrap: int = 20000
    ci_level: float = 0.95
    seed: int = 20260720
    filters: dict = field(default_factory=dict)
    metrics: tuple = ("REC", "RES", "AP", "NDCG@5", "Top-1", "Hit@1", "Empty")


ROBOREFIT_TESTA = EvaluationProtocol(
    name="RoboRefIt testA",
    split="testA",
    n_bootstrap=20000,
    metrics=("REC", "RES"),
    filters={"ground_truth_box": False},
)

ROBOREFIT_TESTB_300 = EvaluationProtocol(
    name="RoboRefIt frozen testB-300",
    split="testB-300",
    n_bootstrap=20000,
    metrics=("Empty", "AP", "NDCG@5", "Top-1", "Hit@1"),
    filters={"frozen_backend": True, "frozen_query_inputs": True},
)

OCID_VLG_NOVEL = EvaluationProtocol(
    name="OCID-VLG novel split",
    split="novel",
    n_bootstrap=20000,
    metrics=("mIoU", "empty_rate"),
    filters={"unseen_classes": True},
)

GRASPNET_OFFICIAL = EvaluationProtocol(
    name="GraspNet-1Billion official",
    split="test",
    n_bootstrap=20000,
    metrics=("AP", "AP_seen", "AP_similar", "AP_novel"),
    filters={"official_protocol": True, "real_sense_frames": 23040},
)


PROTOCOLS = {
    "roborefit_testa": ROBOREFIT_TESTA,
    "roborefit_testb_300": ROBOREFIT_TESTB_300,
    "ocid_vlg_novel": OCID_VLG_NOVEL,
    "graspnet_official": GRASPNET_OFFICIAL,
}
