"""URSC self-contained demo.

This demonstrates the *mechanisms*, not the trained models: the empty-triggered
conditional re-sampling, the uncertainty-modulated context ratio, and the
spatial-consistency calibration over the complete query support.

It uses synthetic masks / depth / point clouds so it can run without datasets,
checkpoints, or the frozen grasp backends. It is a structural reference, not an
evaluation.
"""

from __future__ import annotations

import os
import sys

import numpy as np

# Make the repository root importable so the demo runs from any cwd.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ursc.config import URSCConfig
from ursc.pipeline import URSC
from ursc.stage2 import SpatialConsistencyFilter


class _SyntheticFrontEnd:
    def localize(self, image, text):
        H, W = image.shape[:2]
        m_h = np.zeros((H, W), dtype=np.float64)
        m_h[20:60, 40:90] = 1.0          # a soft language mask
        return m_h, np.array([40, 20, 90, 60])

    def segment(self, image, box):
        H, W = image.shape[:2]
        m1 = np.zeros((H, W), dtype=np.float64)
        m1[18:58, 42:92] = 1.0
        m2 = np.zeros((H, W), dtype=np.float64)
        m2[22:62, 38:88] = 1.0
        return [m1, m2], np.array([0.85, 0.70])


class _SyntheticBackend:
    """Simulate the frozen downstream module.

    The nominal branch is empty on its first invocation (box crop truncates the
    target) and returns candidate queries on re-sampling. This is the simplest
    faithful way to demonstrate the empty-triggered conditional re-sampling
    mechanism without real grasp backends.
    """

    def __init__(self):
        self._calls = 0

    def generate(self, points):
        self._calls += 1
        if self._calls == 1:
            # Nominal branch (box crop) -> empty response (C_b == empty).
            return {"poses": np.zeros((0, 4, 4)), "scores": np.zeros(0), "empty": True}
        # Re-sampled branch -> candidate queries.
        poses = np.zeros((5, 4, 4))
        for i in range(5):
            poses[i] = np.eye(4)
            poses[i, :3, 3] = [0.0, 0.0, 0.4 + i * 0.05]
        scores = np.array([0.9, 0.7, 0.6, 0.5, 0.2])
        return {"poses": poses, "scores": scores, "empty": False}


def main():
    cfg = URSCConfig().validated()
    H, W = 128, 128
    rng = np.random.default_rng(7)
    image = rng.normal(size=(H, W, 3)).astype(np.float32)
    depth = np.full((H, W), 3.0, dtype=np.float64)
    depth[40:60, 60:80] = np.nan        # missing depth inside a region
    intrinsics = np.array([[200.0, 0.0, 64.0], [0.0, 200.0, 64.0], [0.0, 0.0, 1.0]])

    front = _SyntheticFrontEnd()
    backend = _SyntheticBackend()

    model = URSC(cfg, front, front, backend)
    out = model.forward(image, depth, intrinsics, "the blue mug")
    print("=== URSC pipeline (empty-triggered re-sampling) ===")
    print(f"  source          : {out.source!r}  (nominal empty -> re-sampled)")
    print(f"  U (uncertainty) : {out.U:.3f}")
    print(f"  top-1 pose      : {out.ranked_order[0]}")
    print(f"  calibrated      : {out.calibrated_scores.round(3)}")

    # Demonstrate the spatial-consistency filter directly.
    print("\n=== Spatial-consistency calibration over the query support ===")
    m_h, _ = front.localize(image, "the blue mug")
    m_hat = front.segment(image, np.array([40, 20, 90, 60]))[0][0] > 0.5
    filt = SpatialConsistencyFilter(cfg)
    poses = np.tile(np.eye(4), (2, 1, 1))
    poses[:, :3, 3] = [0.0, 0.0, 0.5]
    p = filt.support_p(poses, m_hat, intrinsics)
    print(f"  support p_i     : {p.round(3)}")
    s = filt.calibrate(np.array([0.9, 0.3]), p)
    print(f"  calibrated S_i  : {s.round(3)}")
    print(f"  (a query whose support lies on a neighbor scores lower than one on-target)")

    # Demonstrate the config validation and the U-modulated ratios.
    print("\n=== Disagreement-modulated context ratio r_ctx(U) ===")
    for U in (0.1, 0.5, 0.9):
        r_ctx = float(np.clip(cfg.beta0 + cfg.beta1 * U, cfg.r_ctx_min, cfg.r_ctx_max))
        r_core = max(0.0, 1.0 - cfg.r_bdry - r_ctx)
        print(f"  U={U:.1f} -> r_ctx={r_ctx:.3f}, r_core={r_core:.3f}")


if __name__ == "__main__":
    main()
