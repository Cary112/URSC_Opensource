"""URSC: Uncertainty-Aware Re-sampling with Spatial-Consistency Calibration.

Reference structure for the ICASSP-2026 paper "URSC: Uncertainty-Aware
Re-sampling with Spatial-Consistency Calibration for Multimodal Feature
Fusion".
"""

from .config import URSCConfig, DEFAULT_URSC_CONFIG
from .pipeline import URSC, PipelinedResult
from .stage1 import PromptConstrainedMaskRefinement, CrossModelFeatureUncertainty
from .stage2 import (
    DisagreementGuidedResampling,
    ResamplingController,
    SpatialConsistencyFilter,
)

__all__ = [
    "URSCConfig",
    "DEFAULT_URSC_CONFIG",
    "URSC",
    "PipelinedResult",
    "PromptConstrainedMaskRefinement",
    "CrossModelFeatureUncertainty",
    "DisagreementGuidedResampling",
    "ResamplingController",
    "SpatialConsistencyFilter",
]
