"""URSC configuration and notation.

Notation follows the ICASSP-2026 paper "URSC: Uncertainty-Aware Re-sampling
with Spatial-Consistency Calibration for Multimodal Feature Fusion":

  lambda_sel, lambda_conf : weights of the language overlap vs. the SAM
                            confidence in candidate-mask selection
                            (lambda_sel + lambda_conf = 1).
  beta0, beta1            : baseline context ratio and its response to the
                            cross-model feature-uncertainty U.
  r_ctx_min/max           : clipping bounds of the context ratio.
  r_bdry                  : boundary-point ratio in the re-sampled cloud.
  point_budget            : total number of points in a re-sampled cloud.
  consistency_lambda      : weight of the spatial-consistency term in the
                            calibration score S_i (lambda in the paper).
  action_grid             : sampling grid (closing x fingers x approach) used
                            to build the query-support volume V_i.
  erode_radius            : morphological radius for core / boundary / context.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class URSCConfig:
    """Static configuration of the URSC pipeline.

    Values are the discrete optimum of the pointwise sweep reported in the
    paper's Table 1 (step 0.1, refined to 0.05 where needed); local refinement
    yields no noticeable gain.
    """

    # Stage I: prompt-constrained mask refinement score
    lambda_sel: float = 0.7          # weight of IoU(m_k, m_h)
    lambda_conf: float = 0.3         # weight of SAM confidence c_k
    # Stage II: disagreement-guided re-sampling context ratio
    beta0: float = 0.15              # r_ctx(U) = clip(beta0 + beta1*U, ...)
    beta1: float = 0.35
    r_ctx_min: float = 0.15
    r_ctx_max: float = 0.40
    r_bdry: float = 0.20             # rho, boundary-point ratio
    point_budget: int = 20000
    # Stage II: spatial-consistency calibration score
    consistency_lambda: float = 0.75
    action_grid: tuple = (7, 31, 3)  # closing x fingers x approach
    erode_radius: int = 2
    # Stage I morphology for core / boundary / context partition
    context_dilation_radius: int = 10

    def validated(self) -> "URSCConfig":
        if not 0.0 <= self.lambda_sel <= 1.0:
            raise ValueError("lambda_sel must be in [0, 1]")
        if abs(self.lambda_sel + self.lambda_conf - 1.0) > 1e-6:
            raise ValueError("lambda_sel + lambda_conf must equal 1")
        if not 0.0 <= self.r_ctx_min <= self.r_ctx_max < 1.0:
            raise ValueError("context ratio bounds must satisfy 0 <= min <= max < 1")
        if not 0.0 <= self.r_bdry < 1.0:
            raise ValueError("r_bdry must be in [0, 1)")
        if self.r_bdry + self.r_ctx_max >= 1.0:
            raise ValueError("r_bdry + r_ctx_max must be less than one")
        if not 0.0 <= self.consistency_lambda <= 1.0:
            raise ValueError("consistency_lambda must be in [0, 1]")
        if self.point_budget <= 0:
            raise ValueError("point_budget must be positive")
        return self


DEFAULT_URSC_CONFIG = URSCConfig()
