"""URSC pipeline: uncertainty-aware re-sampling with spatial-consistency
calibration.

External components (front end, SAM, grasp backend) are injected through
protocols; this module defines the control flow and the intermediate
representations. The nominal branch runs first; re-sampling is triggered only
when no valid query survives; survivors are calibrated by the spatial
consistency of the complete query support.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import numpy as np

from .config import URSCConfig
from .stage1 import StageI
from .stage2 import ResamplingController, SpatialConsistencyFilter


class FrontEnd(Protocol):
    def localize(self, image: np.ndarray, text: str):
        """Return (soft_mask (H,W), box (4,) as x1,y1,x2,y2)."""
        ...


class SAM(Protocol):
    def segment(self, image: np.ndarray, box: np.ndarray):
        """Return (candidate_masks list of (H,W), confidences (K,))."""
        ...


class Backend(Protocol):
    def generate(self, points: np.ndarray):
        """Return dict with 'poses' (M,4,4), 'scores' (M,), 'empty' (bool)."""
        ...


def backproject(depth: np.ndarray, intrinsics: np.ndarray):
    """Back-project valid depth pixels to camera-frame points.

    Valid depth is finite, positive, and within [d_min, d_max] (callers apply
    the range check).
    """
    H, W = depth.shape
    y, x = np.mgrid[0:H, 0:W]
    z = depth.astype(np.float64)
    fx, fy = intrinsics[0, 0], intrinsics[1, 1]
    cx, cy = intrinsics[0, 2], intrinsics[1, 2]
    px = (x - cx) * z / fx
    py = (y - cy) * z / fy
    points = np.stack([px, py, z], axis=-1).reshape(-1, 3)
    pix = np.stack([x, y], axis=-1).reshape(-1, 2).astype(np.int64)
    valid = np.isfinite(z) & (z > 0)
    return points, pix, valid.reshape(-1)


@dataclass
class PipelinedResult:
    source: str            # "nominal" or "resample"
    m_h: np.ndarray
    m_hat: np.ndarray
    U: float
    calibrated_scores: np.ndarray
    ranked_order: np.ndarray
    supports: np.ndarray


class URSC:
    """Uncertainty-aware re-sampling with spatial-consistency calibration."""

    def __init__(
        self,
        cfg: URSCConfig,
        front_end: FrontEnd,
        sam: SAM,
        backend: Backend,
    ):
        self.cfg = cfg
        self.front_end = front_end
        self.sam = sam
        self.backend = backend
        self.stage1 = StageI(cfg, front_end, sam)
        self.resampling = ResamplingController(cfg)
        self.filter = SpatialConsistencyFilter(cfg)

    def forward(
        self,
        image: np.ndarray,
        depth: np.ndarray,
        intrinsics: np.ndarray,
        instruction: str,
    ) -> PipelinedResult:
        # Stage I -----------------------------------------------------------
        s1 = self.stage1.forward(image, instruction)
        m_hat, b_h, U = s1["m_hat"], s1["box"], s1["U"]
        scene_points, scene_px, valid = backproject(depth, intrinsics)

        # Stage II: nominal branch (box crop) -------------------------------
        x1, y1, x2, y2 = [int(v) for v in b_h]
        inside_box = (
            (scene_px[:, 0] >= x1) & (scene_px[:, 0] <= x2)
            & (scene_px[:, 1] >= y1) & (scene_px[:, 1] <= y2)
        ) & valid
        P_b = scene_points[inside_box][: self.cfg.point_budget]
        if P_b.shape[0] < self.cfg.point_budget:
            P_b = np.concatenate(
                [P_b, scene_points[valid][: self.cfg.point_budget - P_b.shape[0]]]
            )
        result_b = self.backend.generate(P_b)
        empty_b = bool(result_b["empty"])

        if empty_b:
            # Empty-triggered conditional re-sampling -----------------------.
            P_a = self.resampling.build_cloud(scene_points, scene_px, m_hat, U)
            result = self.backend.generate(P_a)
            source = "resample"
            poses = result["poses"]
            geometric = result["scores"]
        else:
            result = result_b
            source = "nominal"
            poses = result["poses"]
            geometric = result["scores"]

        # Spatial-consistency calibration over the complete query support ---.
        supports = self.filter.support_p(poses, m_hat, intrinsics)
        calibrated = self.filter.calibrate(geometric, supports)
        order = np.argsort(calibrated)[::-1]
        return PipelinedResult(
            source=source,
            m_h=s1["m_h"],
            m_hat=m_hat,
            U=U,
            calibrated_scores=calibrated,
            ranked_order=order,
            supports=supports,
        )
