"""Stage I: language-conditioned target understanding.

This module implements the structure described in the paper's Stage I, which
refines the language-conditioned 2D mask and produces the cross-model
feature-uncertainty estimate U.

  s_k^sel = lambda_sel * IoU(m_k, m_h) + lambda_conf * c_k
  k*      = argmax_k s_k^sel
  m_hat   = m_{k*}
  U       = 1 - IoU(m_h, m_hat)

U never triggers re-sampling by itself; it only adjusts the context proportion
of a re-sampled point cloud *after* an empty nominal-branch response.
"""

from __future__ import annotations

from typing import Sequence

import numpy as np

from .config import URSCConfig


def mask_iou(a: np.ndarray, b: np.ndarray) -> float:
    """IoU of two boolean masks (the union is clamped to the union domain)."""
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    return float(inter / union) if union else 1.0


class PromptConstrainedMaskRefinement:
    """Select the SAM candidate mask balancing language overlap and confidence.

    The box b_h is turned into a SAM box prompt, and the positive points are
    sampled from stable high-response locations in m_h. Candidate masks are
    scored by Eq. (1) of the paper.
    """

    def __init__(self, cfg: URSCConfig):
        self.cfg = cfg
        self.lambda_sel = cfg.lambda_sel
        self.lambda_conf = cfg.lambda_conf

    def select(
        self,
        m_h: np.ndarray,                     # (H, W) float / bool language mask
        candidates: Sequence[np.ndarray],    # list of (H, W) SAM candidate masks
        confidences: np.ndarray,             # (K,) SAM confidences
    ) -> tuple[np.ndarray, int, float]:
        """Return (m_hat, k*, IoU(m_h, m_hat))."""
        m_h_b = m_h > 0.5
        best_k, best_score = 0, -np.inf
        best_iou = 0.0
        for k, m_k in enumerate(candidates):
            c_k = float(confidences[k])
            iou = mask_iou(m_h_b, m_k > 0.5)
            score = self.lambda_sel * iou + self.lambda_conf * c_k
            if score > best_score:
                best_score, best_k, best_iou = score, k, iou
        return candidates[best_k].astype(bool), best_k, best_iou


class CrossModelFeatureUncertainty:
    """U = 1 - IoU(m_h, m_hat), the cross-model feature-uncertainty estimate.

    The disagreement between the language-conditioned mask m_h and the refined
    mask m_hat (from the prompt-constrained SAM refinement) is retained as a
    feature-uncertainty estimate. It is ordinal and never triggers re-sampling
    on its own.
    """

    def __call__(self, m_h: np.ndarray, m_hat: np.ndarray) -> float:
        return 1.0 - mask_iou(m_h > 0.5, m_hat > 0.5)


class StageI:
    """Stage I composition: language-conditioned localization + refinement."""

    def __init__(self, cfg: URSCConfig, front_end, sam):
        # front_end.localize(image, instruction) -> (m_h (H,W), box (4,))
        # sam.segment(image, box) -> (candidate_masks list, confidences (K,))
        self.cfg = cfg
        self.front_end = front_end
        self.sam = sam
        self.refinement = PromptConstrainedMaskRefinement(cfg)
        self.uncertainty = CrossModelFeatureUncertainty()

    def forward(self, image: np.ndarray, instruction: str) -> dict:
        m_h, b_h = self.front_end.localize(image, instruction)
        candidates, confidences = self.sam.segment(image, b_h)
        m_hat, k_star, iou = self.refinement.select(m_h, candidates, confidences)
        U = self.uncertainty(m_h, m_hat)
        return {
            "m_h": m_h.astype(bool),
            "m_hat": m_hat,
            "box": b_h,
            "k_star": k_star,
            "U": U,
            "iou": iou,
        }
