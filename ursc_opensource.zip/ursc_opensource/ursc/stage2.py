"""Stage II: 3D candidate generation, re-sampling, and calibration.

This module implements the paper's Stage II. Two interface-level failures are
addressed:

  * Boundary errors, missing depth, or clutter can truncate the 3D feature
    field, leaving an *empty* nominal-branch response.
  * An anchor-point check cannot verify the full query support; a query whose
    anchor lies on the target can still place its support on a neighbor.

URSC keeps every non-empty nominal output and re-samples *only* on empty
responses, using the cross-model feature-uncertainty U to modulate the context
proportion. Survivors are then filtered by the spatial consistency of the
complete query support (not by an anchor point alone).
"""

from __future__ import annotations

import numpy as np
from scipy import ndimage

from .config import URSCConfig


def _erode(mask: np.ndarray, radius: int) -> np.ndarray:
    size = 2 * radius + 1
    structure = np.ones((size, size), dtype=bool)
    return ndimage.binary_erosion(mask.astype(bool), structure=structure, iterations=1)


def _dilate(mask: np.ndarray, radius: int) -> np.ndarray:
    size = 2 * radius + 1
    structure = np.ones((size, size), dtype=bool)
    return ndimage.binary_dilation(mask.astype(bool), structure=structure, iterations=1)


class DisagreementGuidedResampling:
    """Partition the refined mask into core / boundary / context and compute
    the U-modulated sampling ratios (Eq. 3 of the paper):

      r_ctx(U) = clip(beta0 + beta1 * U, r_ctx_min, r_ctx_max)
      r_bdry   = rho
      r_core   = 1 - r_bdry - r_ctx(U)

    The context proportion grows with U; core and boundary shrink accordingly.
    """

    def __init__(self, cfg: URSCConfig):
        self.cfg = cfg

    def regions(self, m_hat: np.ndarray, U: float) -> dict:
        core = _erode(m_hat, self.cfg.erode_radius)
        boundary = np.logical_and(m_hat, ~core)
        context = np.logical_and(
            _dilate(m_hat, self.cfg.context_dilation_radius), ~m_hat
        )
        r_ctx = float(
            np.clip(
                self.cfg.beta0 + self.cfg.beta1 * U,
                self.cfg.r_ctx_min,
                self.cfg.r_ctx_max,
            )
        )
        r_bdry = self.cfg.r_bdry
        r_core = max(0.0, 1.0 - r_bdry - r_ctx)
        return {
            "core": core,
            "boundary": boundary,
            "context": context,
            "r_core": r_core,
            "r_bdry": r_bdry,
            "r_ctx": r_ctx,
        }

    def compose(
        self,
        scene_points: np.ndarray,     # (N, 3)
        region_mask: np.ndarray,      # (H, W) bool
        count: int,
        rng: np.random.Generator,
    ) -> np.ndarray:                  # (count, 3)
        """Sample `count` scene points whose pixels fall inside `region_mask`."""
        idx = np.flatnonzero(region_mask.reshape(-1))
        if idx.size == 0:
            return np.zeros((count, 3), dtype=scene_points.dtype)
        take = min(count, idx.size)
        chosen = rng.choice(idx, size=take, replace=False)
        return scene_points[chosen]


class ResamplingController:
    """The empty-triggered conditional re-sampling controller.

    The nominal branch runs first. Only when no valid query survives
    (C_b == empty) does the controller compose a re-sampled point cloud
    P_a(U) under a fixed budget, with U controlling only the context
    proportion.
    """

    def __init__(self, cfg: URSCConfig):
        self.cfg = cfg
        self.sampler = DisagreementGuidedResampling(cfg)

    def build_cloud(
        self,
        scene_points: np.ndarray,     # (N, 3)
        scene_px: np.ndarray,         # (N, 2) integer pixel coords
        m_hat: np.ndarray,            # (H, W) bool refined mask
        U: float,
        seed: int = 20260720,
    ) -> np.ndarray:
        regions = self.sampler.regions(m_hat, U)
        rng = np.random.default_rng(seed)
        counts = (
            np.array([regions["r_core"], regions["r_bdry"], regions["r_ctx"]])
            * self.cfg.point_budget
        ).round().astype(int)
        H, W = m_hat.shape
        px = scene_px
        H_img, W_img = H, W
        px_clamped = np.clip(px, 0, [W_img - 1, H_img - 1])
        # map each scene point to its mask membership
        in_core = regions["core"][px_clamped[:, 1], px_clamped[:, 0]]
        in_boundary = regions["boundary"][px_clamped[:, 1], px_clamped[:, 0]]
        in_context = regions["context"][px_clamped[:, 1], px_clamped[:, 0]]
        parts = []
        for mask, count in (
            (in_core, int(counts[0])),
            (in_boundary, int(counts[1])),
            (in_context, int(counts[2])),
        ):
            sel_idx = np.flatnonzero(mask)
            if sel_idx.size == 0:
                parts.append(np.zeros((count, 3), dtype=scene_points.dtype))
                continue
            take = min(count, sel_idx.size)
            chosen = rng.choice(sel_idx, size=take, replace=False)
            parts.append(scene_points[chosen])
        cloud = np.concatenate(parts, axis=0)[: self.cfg.point_budget]
        if cloud.shape[0] < self.cfg.point_budget:
            deficit = self.cfg.point_budget - cloud.shape[0]
            fill_idx = np.flatnonzero(regions["boundary"])[:deficit]
            if fill_idx.size > 0:
                fill = scene_points[fill_idx]
                cloud = np.concatenate([cloud, fill], axis=0)[: self.cfg.point_budget]
        return cloud


class SpatialConsistencyFilter:
    """Filter queries by the spatial consistency of the complete query support.

    For each candidate g_i a support region A(g_i) covers the fingers, the
    closing volume, and the swept approach volume of the downstream query
    (here a 6-DoF grasp). Sampling it, transforming by (R_i, t_i), and
    projecting into m_hat gives

      p_i = (1 / |V_i|) * sum_{x in V_i} m_hat(Pi_K(x))
      S_i = (1 - lambda) * s_i + lambda * p_i

    where s_i are normalized within the candidate set. An anchor can lie
    inside m_hat even when a finger or approach path crosses a neighbor, so
    the full support must be checked, not a single anchor point.
    """

    def __init__(self, cfg: URSCConfig):
        self.cfg = cfg
        gx, gy, gz = cfg.action_grid
        xs = np.linspace(-1.0, 1.0, gx)
        ys = np.linspace(-1.0, 1.0, gy)
        zs = np.linspace(-1.0, 1.0, gz)
        self._grid = np.stack(np.meshgrid(xs, ys, zs, indexing="ij"), axis=-1).reshape(-1, 3)

    def support_p(
        self,
        poses: np.ndarray,            # (M, 4, 4) camera-frame candidate poses
        m_hat: np.ndarray,            # (H, W) bool refined mask
        intrinsics: np.ndarray,       # (3, 3)
    ) -> np.ndarray:                  # (M,)
        """p_i for every candidate, computed over the *complete* query support."""
        M = poses.shape[0]
        if M == 0:
            return np.zeros(0, dtype=float)
        V = self._grid.shape[0]
        R = poses[:, :3, :3]          # (M, 3, 3)
        t = poses[:, :3, 3]           # (M, 3)
        # x = R_i @ x0 + t_i for each candidate i.
        x = self._grid[None, :, :] @ R.transpose(0, 2, 1) + t[:, None, :]  # (M, V, 3)
        z = x[..., 2]
        fx, fy = intrinsics[0, 0], intrinsics[1, 1]
        cx, cy = intrinsics[0, 2], intrinsics[1, 2]
        u = x[..., 0] * fx / np.maximum(z, 1e-3) + cx
        v = x[..., 1] * fy / np.maximum(z, 1e-3) + cy
        valid = (
            (u >= 0) & (u < m_hat.shape[1] - 1)
            & (v >= 0) & (v < m_hat.shape[0] - 1)
        )
        ui = np.clip(np.round(u).astype(int), 0, m_hat.shape[1] - 1)
        vi = np.clip(np.round(v).astype(int), 0, m_hat.shape[0] - 1)
        hit = m_hat[vi, ui]             # (M, V) boolean
        n_valid = np.maximum(valid.sum(-1), 1)
        p = (hit & valid).sum(-1) / n_valid
        return p

    def calibrate(
        self,
        geometric_scores: np.ndarray,  # (M,)
        supports: np.ndarray,          # (M,)
        in_place: bool = True,
    ) -> np.ndarray:                  # (M,) S_i scores
        s = geometric_scores
        if in_place and s.size > 0 and np.ptp(s) > 0:
            s = (s - s.min()) / (s.max() - s.min())
        lam = self.cfg.consistency_lambda
        return (1.0 - lam) * s + lam * supports
